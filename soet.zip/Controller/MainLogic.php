<?php

// Application Logic File

// File Contains Logic and Queries for Frontend Generation.

if(!isset($_SESSION['DEPARTMENT'])){

    $_SESSION['errorsession'] = "Department Not Set, Please Select Your Department";
    header('location: welcome.php');
    exit();

}

if(!isset($_SESSION['SEMESTER'])){
    $_SESSION['errorsession'] = "Semester Not Set, Please Select Your Semester";
    header('location: welcome.php');
    exit();
}

$DEPARTMENT = $_SESSION['DEPARTMENT'];
$SEMESTER = $_SESSION['SEMESTER'];

// 

$GETDEPARTMENT = mysqli_query($db,"SELECT * FROM departments WHERE id = '$DEPARTMENT'");
$GETSEMESTER = mysqli_query($db,"SELECT * FROM semesters WHERE id = '$SEMESTER'");

if(mysqli_num_rows($GETDEPARTMENT) > 0 || mysqli_num_rows($GETSEMESTER) > 0){
   
    $GETDEPARTMENTARRAY = mysqli_fetch_assoc($GETDEPARTMENT);
    $GETSEMESTERARRAY = mysqli_fetch_assoc($GETSEMESTER);

    $_SESSION['LOGGEDSTATUS'] = "YES";

    $DEPARTMENTNAME = $GETDEPARTMENTARRAY['department_name'];
    $SEMESTERNAME = $GETSEMESTERARRAY['semester'];

    $GETNOTICES = mysqli_query($db,"SELECT * FROM notice WHERE 
    (notice_department = '$DEPARTMENT' OR notice_department = 0) AND (semester = '$SEMESTER' OR semester = 0) ORDER BY(id) DESC LIMIT 3");

    
$GETALLNOTICES = mysqli_query($db,"SELECT * FROM notice WHERE 
(notice_department = '$DEPARTMENT' OR notice_department = 0) AND (semester = '$SEMESTER' OR semester = 0) ORDER BY(id) DESC ");


}else{
    session_destroy();
    header('location: welcome.php');
    exit();
}



?>