<?php

if(isset($_POST['WelcomeForm'])){
    $_SESSION['DEPARTMENT'] = filterData($_POST['department']);
    $_SESSION['SEMESTER'] = filterData($_POST['semester']);

    header('location: index.php');
    exit();
}


?>