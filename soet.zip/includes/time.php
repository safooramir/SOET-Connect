<?php

function CurrentTime(){
    $offset1 = 19800; //converting 5:30 hours to seconds.
    $dateFormat1 = "Y-m-d H:i:s";
    $timeNdate = gmdate($dateFormat1, time() + $offset1);

    return $timeNdate;
}

?>