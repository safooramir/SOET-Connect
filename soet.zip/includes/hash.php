<?php

function HashFunction($plaintext){
    return sha1($plaintext);
}


?>