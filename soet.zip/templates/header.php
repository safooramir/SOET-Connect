<!DOCTYPE html>
<html lang="en">
<head>
    
    

    <!-- Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" href="assets/logo.png">
    <meta name="theme-color" content="#6A2CD8">
    <link rel="manifest" href="manifest.json">
    <!-- Bootstrap Include -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Own Stylesheet -->

    <link rel="stylesheet" href="assets/css/stylesheet.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;0,800;1,300&display=swap" rel="stylesheet">
    <!-- Document Title -->

    <meta property="og:title" content="SoET Connect" />
    <meta property="og:description" content="School Of Engineering and Technology Connect" />

    <title>SoET Connect</title>
</head>
<main>

<!-- Image and text -->
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="index.php">
    <img src="assets/logo.png" width="30" height="30" class="d-inline-block align-top" alt="">
    SoET Connect
  </a>
</nav>
<div class="nav-scroller bg--body shadow-sm">
    <nav class="nav nav-underline" aria-label="Secondary navigation">
      <a class="nav-link active" aria-current="page" href="index.php">Home</a>
      <a class="nav-link" href="AllNotices.php">
        Notices
      </a>
      <a class="nav-link" href="Staff.php">Staff Info</a>
      <a class="nav-link" href="students.php">Students</a>
      <a class="nav-link" href="AllAssignments.php">Assignments</a>
      <a class="nav-link" href="resources.php">Downloads</a>

    </nav>
  </div>
 