
<!--  JavaScript Starts -->

<!-- jQuery JavaScript -->


<script
  src="https://code.jquery.com/jquery-3.5.1.js"
  integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
  crossorigin="anonymous"></script>


<!-- Boostrap JavaScript -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous"></script>
<script src="assets/js/timeTable.js"></script>


  <!-- Footer -->
  <footer class="bg-white">
    <div class="container py-5">
      <div class="row py-4">
        <div class="col-lg-4 col-md-6 mb-4 mb-lg-0"><img src="img/logo.png" alt="" width="180" class="mb-3">
          <p class="font-italic text-muted">SoET Connect</p>
        
        </div>
        <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
          <h6 class="text-uppercase font-weight-bold mb-4">Links</h6>
          <ul class="list-unstyled mb-0">
            <li class="mb-2"><a href="AllNotices.php" class="text-muted">Notices</a></li>
            <li class="mb-2"><a href="students.php" class="text-muted">Students</a></li>
            <li class="mb-2"><a href="Staff.php" class="text-muted">Staff</a></li>
            <li class="mb-2"><a href="resources.php" class="text-muted">Resources</a></li>
          </ul>
        </div>
        <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
          <h6 class="text-uppercase font-weight-bold mb-4">External Links</h6>
          <ul class="list-unstyled mb-0">
            <li class="mb-2"><a href="http://www.bgsbu.ac.in/" class="text-muted">University Website</a></li>
            <li class="mb-2"><a href="http://coet.bgsbu.ac.in/src/main.aspx" class="text-muted">SoET Website</a></li>
         </ul>
        </div>
        <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
          <h6 class="text-uppercase font-weight-bold mb-4">External Links</h6>
          <ul class="list-unstyled mb-0">
            <li class="mb-2"><a href="login/index.php" class="text-muted">Login</a></li>
           
          </ul>
        </div>
        <!-- <div class="col-lg-4 col-md-6 mb-lg-0">
          <h6 class="text-uppercase font-weight-bold mb-4"></h6>
          <p class="text-muted mb-4">Lorem ipsum dolor sit amet, consectetur adipisicing elit. At itaque temporibus.</p>
          <div class="p-1 rounded border">
            <div class="input-group">
              <input type="email" placeholder="Enter your email address" aria-describedby="button-addon1" class="form-control border-0 shadow-0">
              <div class="input-group-append">
                <button id="button-addon1" type="submit" class="btn btn-link"><i class="fa fa-paper-plane"></i></button>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>

    <!-- Copyrights -->
    <div class="bg-light py-4">
      <div class="container text-center">
        <p class="mb-0 py-2">© 2021 SoET Connect All rights reserved.</p>
      </div>
    </div>
  </footer>
  <!-- End -->
<!-- Ends JavaScript -->

<script>

if ("serviceWorker" in navigator) {
  // register service worker
  navigator.serviceWorker.register("service-worker.js");
}

</script>
</main>


</body>
</html>