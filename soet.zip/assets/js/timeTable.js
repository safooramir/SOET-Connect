const todayDate = moment().format('YYYY-MM-DD');

const defaultDate = document.getElementById('timetable-date-input').value = todayDate;

const returnSelectedDate = () => {
    return (document.getElementById('timetable-date-input').value);
}

const returnFormattedDate = (date) => {
    return (formattedDate = moment(date).format('DD-MM-YYYY'));
}


$("#timetable-date-input").change(function(){
    let changeDate = returnFormattedDate(returnSelectedDate());
    timeTableData(changeDate);
  
});


function timeTableData(date){
    $.getJSON( `api/timeTableFetch.php`, function ( data ) {
        
        const timetablearray =[];


        for (var i = 0; i < data.length; i++) {
          let date = data[i].date;
          let startTime = moment(data[i].starttime);
          let endTime = moment(data[i].endtime);
          let subjectName = data[i].subject_name;
          let teacher_name = data[i].teacher_name;
          let subject_code = data[i].subject_code;
          let teacher_link = data[i].teacher_link;
          let image_link = data[i].image_link;

          timetablearray.push({date: date, starttime: startTime._i, endtime: endTime._i, subjectname: subjectName, teacher: teacher_name, subject_code: subject_code , teacher_link: teacher_link, image_link: image_link});
        
        }


       

        // Filter array as per date
        
        var filteredValue = timetablearray.filter(function (item) {
           
              return item.date == date;
        });
        
        var timetableslots = ''; 

        for (var i = 0; i < filteredValue.length; i++) {
            
            console.log(filteredValue);
            
            timetableslots += '<div class="col-md-4 p-2"><div class="notice shadow p-4">'+   
            '<span class="badge badge-warning">'+filteredValue[i].starttime+' To '+filteredValue[i].endtime+'</span>'+
            '<p id="time-table-subject-head">'+filteredValue[i].subject_code+'<br/><span>'+filteredValue[i].subjectname+'</span></p>'+ 
            '<p class="image-and-text-tt">'+
            '<img class="img-thumbnail rounded-circle" style="width:30px; height:30px;" src="images/'+filteredValue[i].image_link+'"/>'+
            '<a href="ViewTeacher.php?teacher='+filteredValue[i].teacher_link+'">'+filteredValue[i].teacher+'</a></p></div></div>'
            ;
            
        }

        $("#time-table-row").html(timetableslots);

      
        
        });

            
}



timeTableData(returnFormattedDate(returnSelectedDate()));
