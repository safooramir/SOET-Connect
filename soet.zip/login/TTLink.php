<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php 

include ('controller/authController.php'); 

$DEPARTMENT = $_GET['department'];

if(isset($_POST['AddLink'])){

    $semester = $_POST['semester'];
    $link = $_POST['ttlink'];

    $Add = mysqli_query($db,"INSERT into timetablelinks (department, semester, link)
     VALUES ('$DEPARTMENT','$semester','$link')");

     if($Add){
         $_SESSION['successsession'] = "Link Added Successfully";
         header('location: TTLink.php?department='.$DEPARTMENT.'');
         exit();
     }

}

if(isset($_POST['UpdateLink'])){
    $newlink = $_POST['newlink'];
    $form = $_GET['form'];

    $Update = mysqli_query($db,"UPDATE timetablelinks
     SET link = '$newlink' WHERE id = '$form' ");

    if($Update){
        $_SESSION['successsession']="Link Updated Successfully";
        header('location: TTLink.php?department='.$DEPARTMENT.'');
        exit();
    }
}

?>

<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Time Table Manage</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Department Manage</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
            <!-- Add Department Modal -->
              <a href="#" class="btn btn-lg btn-warning " data-toggle="modal" data-target="#exampleModal">Add Time Table</a>
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Time Table</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        </span>
                        </button>
                    </div>
                    <div class="modal-body">
                    <form name="AddLink" method="POST" action="TTLink.php?department=<?php echo $DEPARTMENT;?> ">
                          
                        <div class="form-group">       
                    <div class="mb-2 text-left">Semester</div>
                        <div class="input-group input-group-merge input-group-alternative mb-2">
                            
                                <select class="form-control" name="semester" id="">
                                <?php

                                $query = mysqli_query($db,"SELECT * FROM semesters");

                                while($q = mysqli_fetch_assoc($query)){
                                    echo '<option value="'.$q['id'].'">'.$q['semester'].'</option>';

                                }

                                
                                ?>
                                
                                </select>
                        </div>
                        </div>
                
                <div class="form-group">       
                <div class="text-left mb-2">Time Table Link</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="ttlink" class="form-control" placeholder="Time Table Link" type="text" required>
                </div>
                </div>
            
            <button class="btn btn-primary btn-lg" name="AddLink">Add Link</button>

            
            </form>
                    </div>
               
                    </div>
                </div>
                </div>
           
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
          <?php include('../includes/dialog.php'); ?>

            <?php

            $fetch_links = mysqli_query($db,"SELECT * FROM timetablelinks WHERE department = '$DEPARTMENT'");

            while($fo = mysqli_fetch_assoc($fetch_links)){
                echo '<form method="POST" name="UpdateLink" action="TTLink.php?department='.$DEPARTMENT.'&form='.$fo['id'].'">
                <p>Semester: '.$fo['semester'].'</p>
                <div class="input-group mb-3">
                 <div class="input-group-prepend">
                
                <span class="input-group-text" id="basic-addon1">Link</span>
                </div>
                <input value="'.$fo['link'].'" required="" name="newlink" type="text" class="form-control" placeholder="New Link" aria-label="Name" aria-describedby="basic-addon1">
                </div>
                
                <button name="UpdateLink" class="btn btn-success">Update</button>

                </form><hr/>';
            }


            ?>


            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <!-- Modal -->

  <?php include ('../login/includes/footer.php');?>