<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php');
include ('../includes/hash.php');
?>

<?php 

$TeacherDetails = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM teachers WHERE id ='$LoggedInTeacher'"));

if(isset($_POST['detailsupdate'])){
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $designation = $_POST['designation'];
    $detail = $_POST['detail'];
    $shortbio = $_POST['shortbio'];


    $update = mysqli_query($db,"UPDATE teachers 
    SET teacher_name = '$name',
    phone = '$phone',
    designation = '$designation',
    details = '$detail',
    shortbio = '$shortbio'
    WHERE id = '$LoggedInTeacher' ");
    
    if($update){
        $_SESSION['successsession'] = "Name Has Been Updated Successfully";
        header('location: TeacherProfile.php');
        exit();
    }
}


if(isset($_POST['updateimage'])){

    $directory = '../images/';
    $filename = $_FILES['newpic']['name'];
  
    $imageExploded = explode(".", $filename);
    $NewFileName = md5($filename) . rand(1000,10000);
  
    $NewFileName = $NewFileName . "." . end($imageExploded);
  
  
    if(move_uploaded_file($_FILES['newpic']['tmp_name'], "../images/" .$NewFileName) ) {
      // database query

      $imageu = mysqli_query($db,"UPDATE teachers SET image = '$NewFileName' WHERE id = '$LoggedInTeacher' ");

      if($imageu){
          $_SESSION['successsession'] = "Image Updated Successfully";
          header('location: TeacherProfile.php');
          exit();
      }
    
  
    }else {
  
      // error
    }
  
  }


if(isset($_POST['updatepassword'])){
    
  $password =  HashFunction($_POST['password']);
  
    $update = mysqli_query($db,"UPDATE teachers SET teacher_password = '$password' WHERE id = '$LoggedInTeacher' ");
    
    if($update){
        $_SESSION['successsession'] = "Password Been Updated Successfully";
        header('location: TeacherProfile.php');
        exit();
    }
}

?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Subject Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->
<a type="button" href="AddSubject.php" class="btn btn-warning">
  Add New Subject
</a>

            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
                <form name="updateimage" method="POST" enctype="multipart/form-data" action="TeacherProfile.php">

                <div class="form-group">       
                <div class="text-muted mb-2">Update Image</div>
                <img src="../images/<?php echo $TeacherDetails['image']; ?>" height="150px" alt="Teacher Image">
                <div class="input-group input-group-merge input-group-alternative mb-2">
                    <br/>
                 <input name="newpic" type="file" class="form-control" required="">
                </div>
                </div>

                <button name="updateimage" class="btn btn-success">Update Image</button>

                </form>
               
                <br/><hr/>
                <form name="detailsupdate" method="POST" action="TeacherProfile.php">

                <div class="form-group">       
                <div class=" mb-2">Your Name</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input value="<?php echo $TeacherDetails['teacher_name']; ?>" name="name" class="form-control" placeholder="Teacher Name" type="text">
                </div>
                </div>
                <div class="form-group">       
                <div class=" mb-2">Phone Number</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input value="<?php echo $TeacherDetails['phone']; ?>" name="phone" class="form-control" placeholder="Phone Number" type="text">
                </div>
                </div>
                <div class="form-group">       
                <div class=" mb-2">Designation</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input value="<?php echo $TeacherDetails['designation']; ?>" name="designation" class="form-control" placeholder="Designation" type="text">
                </div>
                </div>
                <div class="form-group">       
                <div class=" mb-2">Short Bio</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input value="<?php echo $TeacherDetails['shortbio']; ?>" name="shortbio" class="form-control" placeholder="Short Bio" type="text">
                </div>
                </div>
                <div class="mb-2">Teacher Profile Details</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <textarea name="detail" id="summernote" cols="100" rows="30">
                <?php echo $TeacherDetails['details']; ?>
                </textarea>
                </div>
                <button name="detailsupdate" class="btn btn-success">Update Details</button>
                
                </form>
                <br/>
                <br/><hr/>
                <form name="updatepassword" method="POST" action="TeacherProfile.php">

                <div class="form-group">       
                <div class=" mb-2">Password</div>
                <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="password" class="form-control" type="text" required="">
                </div>
                </div>
                <button name="updatepassword" class="btn btn-success">Update Password</button>

                </form>

            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>