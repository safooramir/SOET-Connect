<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php include ('../includes/time.php'); ?>
<?php include ('controller/NoticeController.php'); ?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Default</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
             
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card p-5">
          
  
          <!-- Content Goes Here -->
          
                      <!-- Light table -->
            <form name="addNotice" action="AddNotice.php" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Notice Title</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="noticetitle" class="form-control" placeholder="Enter Notice Title" type="text">
            </div>
            </div>

            <div class="form-group">       
           <div class="text-muted mb-2">Enter Department</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                
                <select name="department" id="" class="form-control">
                    <?php

                    $getdepartments = mysqli_query($db,"SELECT * FROM departments");


                    if($_SESSION['LoggedInDepartment'] == 0) {

                      echo '<option value="0">All</option>';
                      
                      while($department = mysqli_fetch_assoc($getdepartments)){

                        echo '<option value="'.$department['id'].'">'.$department['department_name'].'</option>';

                      }
                    }else{
                      echo '<option value="'.$_SESSION['LoggedInDepartment'].'">'.$_SESSION['LoggedInDepartmentName'].'</option>';

                    }
                   



                    ?>
                </select>

            </div>
            </div>
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Semester</div>
            <div name="sem" class="input-group input-group-merge input-group-alternative mb-2">
                
                  <select class="form-control" name="semester" id="">
                  <?php

                  $getsemesters = mysqli_query($db,"SELECT * FROM semesters");
                  echo '<option value="0">All</option>';
                  while($sem = mysqli_fetch_assoc($getsemesters)){
                    echo '<option value="'.$sem['id'].'">'.$sem['semester'].'</option>
                    ';
                  }
                  ?>
                  </select>

            </div>
            </div>

            <div class="form-group">       
           <div class="text-muted mb-2">Enter Notice Details</div>
            <div name="noticedetails" class="input-group input-group-merge input-group-alternative mb-2">
                
                <textarea name="detail" id="summernote" cols="100" rows="30"></textarea>
               

            </div>
            </div>
            
            <button name="addNotice" class="btn btn-success btn-lg">Add Notice</button>

            
            </form>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>