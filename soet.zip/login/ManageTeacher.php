<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('../includes/hash.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php 


if(isset($_GET['teacher'])){
  $teacher = $_GET['teacher'];
  $q = mysqli_query($db,"SELECT * FROM teachers WHERE id = '$teacher'");

  $teacherdetail = mysqli_fetch_assoc($q);

  if(isset($_GET['action'])){
    $action = $_GET['action'];
    if($action=='delete'){
      $queryDe = mysqli_query($db,"DELETE FROM teachers WHERE id = '$teacher'");

      if($queryDe){
        $_SESSION['successsession'] = "Teacher Deleted Successfully";
        header('location: TeacherManagement.php');
        exit();
      }
    }
  }
}

if(isset($_POST['changepassword'])){

  $teacher = $_GET['teacher'];

  $newPassword = HashFunction($_POST['password']);

  $updatepassword = mysqli_query($db,"UPDATE teachers SET teacher_password = '$newPassword' WHERE id = '$teacher' ");
 
  if($updatepassword){
    $_SESSION['successsession'] = "Teacher Password Updated Successfully";
    header('location: ManageTeacher.php?teacher='.$teacher.'');
    exit();
  }

}

if(isset($_POST['loginstate'])){

  $teacher = $_GET['teacher'];
  
  $getstate = $_POST['newstate'];

  $updatestate = mysqli_query($db,"UPDATE teachers SET login_state = '$getstate' WHERE id = '$teacher'");

  if($updatestate){
    $_SESSION['successsession'] = "Login State Updated Succcessfully";
    header('location: ManageTeacher.php?teacher='.$teacher.'');
    exit();
  }

}

if(isset($_POST['changeemail'])){


  $teacher = $_GET['teacher'];
  
  $newemail = $_POST['email'];

  $updatestate = mysqli_query($db,"UPDATE teachers SET teacher_email = '$newemail' WHERE id = '$teacher'");

  if($updatestate){
    $_SESSION['successsession'] = "Email Updated Succcessfully";
    header('location: ManageTeacher.php?teacher='.$teacher.'');
    exit();
  }

}

?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Default</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
        <?php include('../includes/dialog.php'); ?>

          <div class="card p-5">
          
            <p>Login State:
            <?php if($teacherdetail['login_state'] == 1){
              echo '<span class="text-success">Enabled';
            }else{
              echo '<span class="text-danger">Disabled';
            } ?></span></p>
          <!-- Content Goes Here -->
          <form name="loginstate" action="ManageTeacher.php?teacher=<?php echo $teacher; ?>" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enable/Disable Login</div>

              <select name="newstate" class="form-control" id="">

                <option value="1" class="form-control">On</option>
                <option value="0" class="form-control">Off</option>

              </select>

            </div>
            <button name="loginstate" class="btn btn-success btn-lg">Change Login State</button>
            </form>
            <hr/>
                      <!-- Light table -->
            <form name="changepassword" action="ManageTeacher.php?teacher=<?php echo $teacher; ?>" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">New Password</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="password" class="form-control" placeholder="Enter New Password" type="text">
            </div>
            </div>
            <button name="changepassword" class="btn btn-success btn-lg">Update Password</button>

            
            </form>

            <hr/>

            <form name="changeemail" action="ManageTeacher.php?teacher=<?php echo $teacher; ?>" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Change Email</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="email" class="form-control" placeholder="Enter New Email" value="<?php echo $teacherdetail['teacher_email']; ?>" type="text">
            </div>
            </div>
            <button name="changeemail" class="btn btn-success btn-lg">Update Email</button>

            
            </form>

            <hr/>

          <a href="ManageTeacher.php?action=delete&teacher=<?php echo $teacher; ?>" class="btn btn-danger">Delete Teacher</a>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>