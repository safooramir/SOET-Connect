<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php include ('../includes/time.php'); ?>
<?php 

$BATCH = $_GET['batch'];

$Q = mysqli_query($db,"SELECT * FROM batches WHERE id = '$BATCH'");

$BATCHDATA = mysqli_fetch_assoc($Q);

if(isset($_POST['EditBatch'])){
    $department = $_POST['department'];
    $name = $_POST['name'];
    $semester = $_POST['semester'];

    $update = mysqli_query($db,"UPDATE batches
     SET batch_name = '$name',
     batch_department = '$department',
     batch_semester = '$semester'
     WHERE id = '$BATCH' ");

    if($update){
        $_SESSION['successsession'] = "Batch Updated Successfully";
        header('location: EditBatch.php?batch='.$BATCH.'');
        exit();
    }
}

if(isset($_GET['action'])){
    if($_GET['action']=='delete'){
        $delete = mysqli_query($db,"DELETE FROM batches WHERE id = '$BATCH'");

        if($delete){
            $_SESSION['successsession'] = "Batch Deleted Successfully";
            header('location: StudentManagement.php');
            exit();
        }
    }
}

?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Edit Batch</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
             
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card p-5">
          
  
          <!-- Content Goes Here -->

          <div>
            <?php include('../includes/dialog.php'); ?>
          </div>
          
                      <!-- Light table -->
            <form name="EditBatch" action="EditBatch.php?batch=<?php echo $BATCH;?>" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Batch Name</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="name" value="<?php echo $BATCHDATA['batch_name']; ?>" class="form-control" placeholder="Enter Notice Title" type="text" required>
            </div> 
            </div>

            <div class="form-group">       
           <div class="text-muted mb-2">Batch Department</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <select class="form-control" name="department" id="">
                <?php

                $depart = mysqli_query($db,"SELECT * FROM departments");

                while($d = mysqli_fetch_assoc($depart)){

                    if($d['id'] == $BATCHDATA['batch_department']){
                        echo '<option class="form-control" value="'.$d['id'].'" selected>'.$d['department_name'].'</option>';

                    }else{
                        echo '<option class="form-control" value="'.$d['id'].'">'.$d['department_name'].'</option>';

                    }


                }

                ?>
                
                </select>
               

            </div> 
            </div>
            <div class="form-group">       
           <div class="text-muted mb-2">Batch Semester</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <select class="form-control" name="semester" id="" >
                <?php

                $sem = mysqli_query($db,"SELECT * FROM semesters");

                while($d = mysqli_fetch_assoc($sem)){

                    if($d['id'] == $BATCHDATA['batch_semester']){
                        echo '<option class="form-control" value="'.$d['id'].'" selected>'.$d['semester'].'</option>';

                    }else{
                        echo '<option class="form-control" value="'.$d['id'].'">'.$d['semester'].'</option>';

                    }


                }

                ?>
                
                </select>
               

            </div> 
            </div>

            
            <button name="EditBatch" class="btn btn-success btn-lg">Edit Batch</button>

            
            </form>
           
          </div>
                <div>
                <a class="btn btn-danger" href="EditBatch.php?batch=<?php echo $BATCH;?>&action=delete">Delete Batch</a>

                </div>
        </div>
        
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>