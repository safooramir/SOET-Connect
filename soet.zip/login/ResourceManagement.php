<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php

include ('controller/NoticeController.php'); 

if(isset($_GET['action'])){
  if($_GET['action'] == 'delete'){
    $download = $_GET['download'];

    $deletedownload= mysqli_query($db,"DELETE FROM downloads WHERE id= '$download'");

    if($deletedownload){
      $_SESSION['successsession'] = "Resource Deleted Successfully";
      header('location: ResourceManagement.php');
      exit();

    }
  }
}

if(isset($_POST['UploadResource'])){
    $title = $_POST['title'];
    $department = $_POST['department'];
   
    $filename = $_FILES['file']['name'];
  
    $imageExploded = explode(".", $filename);
    $NewFileName = md5($filename) . rand(1000,10000);
  
    $NewFileName = $NewFileName . "." . end($imageExploded);
  
  
    if(move_uploaded_file($_FILES['file']['tmp_name'], "../downloads/" .$NewFileName) ) {
      // database query

      $imageu = mysqli_query($db,"INSERT into downloads 
      (file_title,department,file_link) VALUES ('$title','$department','$NewFileName')");

      if($imageu){
          $_SESSION['successsession'] = "Resource Uplaoded Successfully";
          header('location: ResourceManagement.php');
          exit();
      }
    
  
    }else {
  
      // error
    }
  
    
   
    
  
  }
?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Resource Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">View Notices</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
            Add Resource
            
            </button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Resource</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="ResourceManagement.php" name="UploadResource" enctype="multipart/form-data">
        <div class="form-group justify-left">
        <p class="text-justify">Resource Title</p>

            <input required="" name="title" type="text" class="form-control" id="exampleInputPassword1" placeholder="Resource Title">
        </div>

    
        <div class="form-group justify-left">
        <p class="text-justify">Resource Department</p>
        <select class="form-control" name="department" id="" required="">

        <?php

            if($LoggedInDepartment == 0){
                
            $getalldepartments = mysqli_query($db,"SELECT * FROM departments");
            echo '<option value="0">All</option>';


            }else{

                $getalldepartments = mysqli_query($db,"SELECT * FROM departments WHERE id = '$LoggedInDepartment'" );

            }
         
            while($department = mysqli_fetch_assoc($getalldepartments)){
                echo '<option value="'.$department['id'].'">'.$department['department_name'].'</option>';
            }
            ?>
            
     

        </select>
        </div>
        <div class="form-group justify-left">
        <p class="text-justify">Resource File</p>

            <input required="" name="file" type="file" class="form-control" id="exampleInputPassword1" >
        </div>
       
        <button type="submit" name="UploadResource" class="btn btn-primary">Submit</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
           
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            
          
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
            <div>
            <?php include('../includes/dialog.php'); ?>

            </div>
              <table id="table_id" class="table align-items-center table-flush p-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Resource Title</th>
                   

                    <th scope="col" class="sort" data-sort="status">Actions</th>
                    
                  </tr>
                </thead>
                <tbody class="list">

                  <?php

                    if($LoggedInDepartment == 0){
                      $getall = mysqli_query($db,"SELECT * FROM downloads ORDER BY(id) DESC");

                    }else{
                      $getall = mysqli_query($db,"SELECT * FROM downloads WHERE department = '$LoggedInDepartment'" );

                    }

 
                    while($download = mysqli_fetch_assoc($getall)){
                      echo '
                      <tr>
                        <th scope="row">
                          <div class="media align-items-center">
                           
                            <div class="media-body">
                              <span class="name mb-0 text-sm">'.$download['file_title'].'</span>
                            </div>
                          </div>
                        </th>
                      
        
                        <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-info" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Manage
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              <a class="dropdown-item" href="ResourceManagement.php?download='.$download['id'].'&action=delete">Delete</a>
                            </div>
                          </div>
                        </td>
                      </tr>';
                    }


                  ?>

               
              
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>