<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php

include ('controller/NoticeController.php'); 

if(isset($_GET['action'])){
  if($_GET['action'] == 'delete'){
    $noticeid = $_GET['id'];

    $deletenotice= mysqli_query($db,"DELETE FROM notice WHERE id= '$noticeid'");

    if($deletenotice){
      $_SESSION['successsession'] = "Notice Deleted Successfully";
      header('location: NoticeManagement.php');
      exit();

    }
  }
}

?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Notice Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">View Notices</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <a href="AddNotice.php" class="btn btn-lg btn-warning">Add New Notice</a>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            
          
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
            <div>
            <?php include('../includes/dialog.php'); ?>

            </div>
              <table id="table_id" class="table align-items-center table-flush p-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Notice Title</th>
                    <th scope="col" class="sort" data-sort="budget">Published Date</th>
                    <th scope="col" class="sort" data-sort="budget">Semester</th>

                    <th scope="col" class="sort" data-sort="status">Actions</th>
                    
                  </tr>
                </thead>
                <tbody class="list">

                  <?php

                    if($LoggedInDepartment == 0){
                      $getall = mysqli_query($db,"SELECT * FROM notice ORDER BY(id) DESC");

                    }else{
                      $getall = mysqli_query($db,"SELECT * FROM notice WHERE notice_department = '$LoggedInDepartment' OR notice_department = 0 ORDER BY(id) DESC" );

                    }

 
                    while($notice = mysqli_fetch_assoc($getall)){
                      echo '
                      <tr>
                        <th scope="row">
                          <div class="media align-items-center">
                           
                            <div class="media-body">
                              <span class="name mb-0 text-sm">'.$notice['notice_title'].'</span>
                            </div>
                          </div>
                        </th>
                      
        
                     
                        <td class="text-right">
                        <div class="dropdown">
                        '.$notice['timestamp'].'
                        </div>
                      </td>
                      <td class="text-right">
                        <div class="dropdown">
                        '.$notice['semester'].'
                        </div>
                      </td>
                        <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-info" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Manage
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              <a class="dropdown-item" href="EditNotice.php?notice='.$notice['id'].'">Edit</a>
                              <a class="dropdown-item" href="NoticeManagement.php?action=delete&id='.$notice['id'].'">Delete</a>
                            </div>
                          </div>
                        </td>
                      </tr>';
                    }


                  ?>

               
              
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>