<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php

if(isset($_GET['notice'])){

    $notice = $_GET['notice'];

    $NoticeDetails = mysqli_query($db,"SELECT * FROM notice WHERE id ='$notice'");

    $noticeinfo = mysqli_fetch_assoc($NoticeDetails);
   
    if(isset($_POST['updatenotice'])){
        $noticeid = $_GET['notice'];
        $noticetitle = $_POST['noticetitle'];
        $detail = $_POST['detail'];
    
        $UpdateNotice = mysqli_query($db,"UPDATE notice 
        SET notice_title = '$noticetitle'
        ,upload_data = '$detail' WHERE id = '$noticeid' ");
    
        if($UpdateNotice){
            $_SESSION['successsession'] = "Notice Updated Successfully";
            header('location: EditNotice.php?notice='.$noticeid.'');
            exit();
        }
    }
}

?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Default</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <a href="#" class="btn btn-lg btn-warning">View Notice</a>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card p-5">
          
          <div>

          <?php include('../includes/dialog.php'); ?>
        </div>
          <!-- Content Goes Here -->
          
                      <!-- Light table -->
            <form name="updatenotice" action="EditNotice.php?notice=<?php echo $notice; ?>" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Notice Title</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="noticetitle" value="<?php echo $noticeinfo['notice_title']; ?>" class="form-control" placeholder="Enter Notice Title" type="text">
            </div>
            </div>

       
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Notice Details</div>
            <div name="noticedetails" class="input-group input-group-merge input-group-alternative mb-2">
                
                <textarea name="detail" id="summernote" cols="100" rows="30">
               <?php echo $noticeinfo['upload_data']; ?>
                </textarea>
               

            </div>
            </div>
            
            <button name="updatenotice" class="btn btn-success btn-lg">Update Notice</button>

            
            </form>

            
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>