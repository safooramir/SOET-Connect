<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php 

if(isset($_GET['student'])){

    $studentid = $_GET['student'];
    
    $q = mysqli_query($db,"SELECT * FROM students WHERE id ='$studentid' ");

    $student = mysqli_fetch_assoc($q);

    if(isset($_GET['action'])){
      $action = $_GET['action'];
      if($action == 'delete'){
        $delete = mysqli_query($db,"DELETE FROM students WHERE id = '$studentid'");

        if($delete){
            $_SESSION['successsession'] = "Student Deleted Successfully!";
            header('location: StudentManagement.php');
            exit();
        }
      }
    }



}else{
  $_SESSION['errorsession'] = "Student Error!. Please Try Again";
  header('location: StudentManagement.php');
  exit();
}

if(isset($_POST['editstudent'])){
    $student = $_GET['student'];
    $name = $_POST['studentname'];
    $email = $_POST['studentemail'];
    $rollno = $_POST['studentrollno'];

    $Update = mysqli_query($db,"UPDATE students SET student_name = '$name', student_email = '$email', student_rollno = '$rollno' ");

    if($Update) {
        $_SESSION['successsession'] = 'Student Details Updated';
        header('location: EditStudent.php?student='.$student.'');
        exit();
    }
}


?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Batch Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Student</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>


      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
    
    <form name="editstudent" method="POST" action="EditStudent.php?student=<?php echo $_GET['student'];?>">
      <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Name</span>
          </div>
          <input required="" value="<?php echo $student['student_name'];?>" name="studentname" type="text" class="form-control" placeholder="Name" aria-label="Name" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Email</span>
          </div>
          <input required="" value="<?php echo $student['student_email'];?>" name="studentemail" type="text" class="form-control" placeholder="Email" aria-label="Name" aria-describedby="basic-addon1">
        </div>
     
        <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Roll No</span>
          </div>
          <input required="" value="<?php echo $student['student_rollno'];?>" name="studentrollno" type="text" class="form-control" placeholder="Roll No" aria-label="Name" aria-describedby="basic-addon1">
        </div>
     
     <button name="editstudent" class="btn btn-success">Edit Student</button>
      </form>

    <br/><br/>

        <a class="btn btn-danger" href="EditStudent.php?student=<?php echo $studentid; ?>&action=delete">Delete Student</a>
         
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>