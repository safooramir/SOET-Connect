<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>

<?php include ('controller/DepartmentController.php'); ?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Time Table Manage</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Department Manage</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
            <!-- Add Department Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                  
                   
                    </div>
                </div>
                </div>
           
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
              <table id="table_id" class="table align-items-center table-flush p-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Department Name</th>
                    <th scope="col" class="sort" data-sort="budget">Edit/View</th>
                   
                  </tr>
                </thead>
                <tbody class="list">
                
                    <?php

                    while($department = mysqli_fetch_assoc($AllDepartmentsQuery)) {

                        echo '<tr>
                        <td>
                          <div class="d-flex align-items-center">
                            <span class="completion mr-2">'.$department['department_name'].'</span>   
                          </div>
                        </td>
                        <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-info" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Manage
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              <a class="dropdown-item" href="TTLink.php?department='.$department['id'].'">Manage Time Table</a>
                              

                            </div>
                          </div>
                        </td>
                      </tr>';

                    }


                    ?>


               
              
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <!-- Modal -->

  <?php include ('../login/includes/footer.php');?>