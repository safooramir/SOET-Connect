<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php 

if(isset($_POST['AddTeacher'])){

    $teachername = $_POST['teachername'];
    $teacheremail = strtolower($_POST['teacheremail']);
    $department = $_POST['department'];

    $checkq = mysqli_query($db,
    "SELECT * FROM teachers WHERE 
    teacher_email = '$teacheremail' LIMIT 1");

    if(mysqli_num_rows($checkq) > 0){
      $_SESSION['errorsession'] = "Email Already Exists";
      header('location: TeacherManagement.php');
      exit();
    }

    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $teachername)));

    $insert = mysqli_query($db,"INSERT into teachers(teacher_name,teacher_email,teacher_slug,teacher_department) VALUES 
    ('$teachername','$teacheremail', '$slug', '$department')");

    if($insert) {
        $_SESSION['successsession'] = "Teacher Added Successfully!";
        header('location: TeacherManagement.php');
        exit();
    }

}


?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Teacher Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->
<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
  Add New Teacher
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Teacher</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="POST" action="TeacherManagement.php" name="AddTeacher">
       
        <div class="form-group">
            <p class="text-justify">Teacher Name</p>
            <input required="" name="teachername" type="text" class="form-control" id="exampleInputPassword1" placeholder="Teacher Name">
        </div>

        <div class="form-group">
            <p class="text-justify">Teacher Email</p>
            <input required="" name="teacheremail" type="text" class="form-control" id="exampleInputPassword1" placeholder="Teacher Email">
        </div>

        <div class="form-group ">
    

          <p class="text-justify">Department</p>
            <select class="form-control" name="department" id="" required="">

            <?php

            $getdepartments = mysqli_query($db,"SELECT * FROM departments");
            if($_SESSION['LoggedInDepartment'] == 0){

                while($department = mysqli_fetch_assoc($getdepartments)){

                    echo '<option value="'.$department['id'].'">'.$department['department_name'].'</option>';

                  }
            }else{

                echo '<option value="'.$LoggedInDepartment.'">'.$_SESSION['LoggedInDepartmentName'].'</option>';

            }

            ?>
            </select>

        </div>


       
        <button type="submit" name="AddTeacher" class="btn btn-primary">Submit</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
              <table id="table_id" class="table align-items-center table-flush p-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Teacher Name</th>
                    <th scope="col" class="sort" data-sort="name">Department</th>

                    <th scope="col" class="sort" data-sort="status">Action</th>
                    
                  </tr>
                </thead>
                <tbody class="list">
                

                  <?php
   
                    if($LoggedInDepartment == 0){

                      $getall = mysqli_query($db,"SELECT * FROM teachers ORDER BY(id) DESC");

                    }else{

                      $getall = mysqli_query($db,"SELECT * FROM teachers WHERE teacher_department = '$LoggedInDepartment'  ORDER BY(id) DESC");

                    }

 
                    while($batch = mysqli_fetch_assoc($getall)){

                      $department = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM departments WHERE id = ".$batch['teacher_department'].""));

                      echo '
                      <tr>
                        <th scope="row">
                          <div class="media align-items-center">
                           
                            <div class="media-body">
                              <span class="name mb-0 text-sm">'.$batch['teacher_name'].'</span>
                            </div>
                          </div>
                        </th>
                        <th scope="row">
                        <div class="media align-items-center">
                         
                          <div class="media-body">
                            <span class="name mb-0 text-sm">'.$department['department_name'].'</span>
                          </div>
                        </div>
                      </th>
                      
                        <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-info" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Manage
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              <a class="dropdown-item" href="ManageTeacher.php?teacher='.$batch['id'].'">Edit</a>
                            </div>
                          </div>
                        </td>
                      </tr>';
                    }


                  ?>

               
              
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>