<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php

if(isset($_POST['addAssignment'])){

    $title = $_POST['title'];
    $date = $_POST['date'];
    $subject = $_POST['subject'];
    $detail = $_POST['detail'];

    $addQ = mysqli_query($db,"INSERT into assignments 
    (assignment_title,
    assignment_subject,
    uploaded_by,
    enddate,
    details) VALUES('$title','$subject','$LoggedInTeacher','$date','$detail')");

    if($addQ){
        $_SESSION['successsession'] = "Assignment Has Been Added Successfully";
        header('location: AssignmentManagement.php');
        exit();
    }


}

?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Assignment Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->
<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
  Add New Assignment
</button>

            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
            <form name="addAssignment" action="AddAssignment.php" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Assignment Title</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="title" class="form-control" placeholder="Enter Assignment Title" type="text">
            </div>
            </div>
            <div class="form-group">       
           <div class="text-muted mb-2">Submission Date</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                    <input class="form-control" type="date" id="" name="date">
            </div>
            </div>
            <div class="text-muted mb-2">Subject</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <select class="form-control" name="subject" id="">
                <?php 
                    $fetch_teacher_subjects = mysqli_query($db,"SELECT * FROM subjects WHERE teacher_assigned = '$LoggedInTeacher'");
                    while($subject = mysqli_fetch_assoc($fetch_teacher_subjects)){
                        echo '<option value="'.$subject['id'].'">'.$subject['subject_code'].'</option>';
                    }
                ?>
                </select>
            </div><br/>
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Assignment Details</div>
            <div name="noticedetails" class="input-group input-group-merge input-group-alternative mb-2">
                
                <textarea name="detail" id="summernote" cols="100" rows="30"></textarea>
               

            </div>
            </div>
            <button name="addAssignment" class="btn btn-success btn-lg">Add Assignment</button>

            </div>
            

            </form>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>