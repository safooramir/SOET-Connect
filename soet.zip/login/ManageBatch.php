<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php 

if(isset($_GET['id']) && isset($_GET['department'])){

    $batchid = $_GET['id'];
    $department = $_GET['department'];

    $getallstudents = mysqli_query($db,"SELECT * FROM students WHERE student_batch = '$batchid' AND student_department = '$department'");

    $getdepartmentname = mysqli_query($db,"SELECT * FROM departments WHERE id = '$department'");

    $departmentname = mysqli_fetch_assoc($getdepartmentname);
    

  }else{
  $_SESSION['errorsession'] = "Department or Batch Error!. Please Try Again";
  header('location: StudentManagement.php');
  exit();
}


if(isset($_POST['addStudent'])) {

  $batchid = $_GET['id'];
  $department = $_GET['department'];
  $studentname = $_POST['studentname'];
  $studentemail = $_POST['studentemail'];
  $studentrollno = $_POST['studentrollno'];

  $AddStudent = mysqli_query($db,"INSERT INTO students (student_name,student_batch,student_department, student_rollno, student_email) 
  VALUES ('$studentname', '$batchid','$department','$studentrollno', '$studentemail')");

  if($AddStudent){
    $_SESSION['successsession'] = "Student Added Successfully";
    header('location: ManageBatch.php?id='.$batchid.'&department='.$department.'');
    exit();
  }


}

?>
<?php include ('../login/includes/header.php') ?>

<!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Batch Management</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->
<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">
  Add New Student
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Student</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      
      <div class="modal-body">
      <form name="addStudent" method="POST" action="ManageBatch.php?id=<?php echo $_GET['id'];?>&department=<?php echo $_GET['department'];?>">
      <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Name</span>
          </div>
          <input required="" name="studentname" type="text" class="form-control" placeholder="Name" aria-label="Name" aria-describedby="basic-addon1">
        </div>

        <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Email</span>
          </div>
          <input required="" name="studentemail" type="text" class="form-control" placeholder="Email" aria-label="Name" aria-describedby="basic-addon1">
        </div>
     
        <div class="input-group mb-3">
        <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1">Roll No</span>
          </div>
          <input required="" name="studentrollno" type="text" class="form-control" placeholder="Roll No" aria-label="Name" aria-describedby="basic-addon1">
        </div>
     
     <button name="addStudent" class="btn btn-success">Add Student</button>
      </form>

      </div>

      
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
        
        <h4>Department: <?php echo $departmentname['department_name']; ?> </h4>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">Roll No</th>
      <th scope="col">Student Name</th>
      <th scope="col">Student Email</th>
      <th scope="col">Manage Student</th>
    </tr>
  </thead>
  <tbody>

  <?php


  while($s = mysqli_fetch_assoc($getallstudents)) {
    echo ' <tr>
    <th scope="row">'.$s['student_rollno'].'</th>
    <td>'.$s['student_name'].'</td>
    <td>'.$s['student_email'].'</td>
    <td><a href="EditStudent.php?student='.$s['id'].'" class="btn btn-primary btn-sm">Edit Student</a></td>
  </tr>';
  }
  ?>
   

  </tbody>
</table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>