<?php


if(isset($_POST['addNotice'])) {

    $noticetitle = $_POST['noticetitle'];
    $detail = $_POST['detail'];
    $department = $LoggedInDepartment;
    $uploadedBy = $_SESSION['LOGGEDUSER'];
    $semester = $_POST['semester'];
    $time = CurrentTime();


    $addNotice = mysqli_query($db,"INSERT into 
    notice (notice_title, notice_department, upload_data, uploaded_by, timestamp,semester ) 
    VALUES ('$noticetitle','$department', '$detail','$uploadedBy','$time', '$semester')");


    if($addNotice) {
        $_SESSION['successsession'] = "Notice Added Successfully";
        header('location: NoticeManagement.php');
        exit();
    }
}



?>