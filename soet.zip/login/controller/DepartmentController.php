<?php

$AllDepartmentsQuery = mysqli_query($db,"SELECT * FROM departments");


// Add New Department 

if(isset($_POST['AddDepartment'])) {

    $departmentName = filterData($_POST['DepartmentName']);

    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $departmentName)));

    $InsertQuery = mysqli_query($db,"INSERT into departments (department_name, department_shortned) VALUES ('$departmentName', '$slug')");


    if($InsertQuery) {
        $_SESSION['successsession'] = "Department Added Successfully";
        header('location: DepartmentManage.php');
        exit();
    }
}


// View Manage Department

?>