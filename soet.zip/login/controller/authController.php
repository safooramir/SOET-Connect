<?php


if( $_SESSION['LOGINSTATE'] !== 'LOGGEDIN'){
    header('location: index.php');
    exit();
}


$GETLOGGEDUSER = $_SESSION['LOGGEDUSER'];

$GETLOGINLEVEL = $_SESSION['LOGINTYPE'];

if($GETLOGINLEVEL == 3){

    $LOGGEDUSEREMAIL = $_SESSION['LOGGEDUSER'];
    $getTeacherDetails = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM teachers WHERE teacher_email = '$LOGGEDUSEREMAIL'"));
    $LoggedInTeacher = $getTeacherDetails['id'];
    $LoggedInDepartment = $getTeacherDetails['teacher_department'];
    $get_department = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM departments WHERE id = '$LoggedInDepartment' "));
    $LoggedInDepartmentName = $get_department['department_name'];
    $LoggedInLevel = 3;


}else{

    $LoggedUser = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM auth WHERE email = '$GETLOGGEDUSER'")); 

    $LoggedInLevel = $LoggedUser['log_type'];
    
    if($LoggedInLevel == 1) {
    
        // Main Admin
    
        $LoggedInDepartment = 0;
        $LoggedInDepartmentName = 'SoET';
    
    }else if($LoggedInLevel == 2) {
    
        // Department
    
        $LoggedInDepartment = $LoggedUser['dept_assigned'];
        $get_department = mysqli_fetch_assoc(mysqli_query($db,"SELECT * FROM departments WHERE id = '$LoggedInDepartment' "));
        
        $LoggedInDepartmentName = $get_department['department_name'];
    
    
    }
}


$_SESSION['LoggedInLevel'] = $LoggedInLevel;
$_SESSION['LoggedInDepartment'] = $LoggedInDepartment;
$_SESSION['LoggedInDepartmentName'] = $LoggedInDepartmentName;


?>