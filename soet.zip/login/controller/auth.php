<?php

include ('../includes/hash.php');

if(isset($_POST['login'])) {
    

    $email = filterData($_POST['email']);
    $password = HashFunction(filterData($_POST['password']));
    $logintype = filterData($_POST['logintype']);

    if($logintype == 2){

        $loginQuery = mysqli_query($db,"SELECT * FROM teachers WHERE teacher_email = '$email' AND teacher_password = '$password' LIMIT 1");

        if(mysqli_num_rows($loginQuery) > 0){
            $_SESSION['LOGINSTATE']= "LOGGEDIN";
            $_SESSION['LOGGEDUSER'] = $email;
            $_SESSION['LOGINTYPE'] = 3; //teacher

            header('location: home.php');
            exit();
        }else{
            $_SESSION['errorsession'] = "Login Failed! Email or Password is Incorrect.";
            header('location: index.php');
            exit();
        }

    }else{
        $loginQuery = mysqli_query($db,"SELECT * FROM auth WHERE email = '$email' AND pass = '$password' LIMIT 1");

        if(mysqli_num_rows($loginQuery) > 0) {
    
            $_SESSION['LOGINSTATE'] = "LOGGEDIN";
            $_SESSION['LOGGEDUSER'] = $email;
            $_SESSION['LOGINTYPE'] = 0; //teacher

            header('location: home.php');
            exit();
    
        }else{
            $_SESSION['errorsession'] = "Login Failed! Email or Password is Incorrect.";
            header('location: index.php');
            exit();
        }
    }



}

?>