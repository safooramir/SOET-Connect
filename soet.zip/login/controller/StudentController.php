<?php

$getdepartments = mysqli_query($db,"SELECT * FROM departments");


if(isset($_POST['AddBatch'])){

    $batchName = $_POST['batchname'];
    $batchdepartment = $_POST['batchdepartment'];
    $batchsemester = $_POST['batchsemester'];

    $insert = mysqli_query($db,"INSERT into batches(batch_name,batch_semester,batch_department) VALUES ('$batchName','$batchsemester','$batchdepartment')");

    if($insert){
        $_SESSION['successsession'] = "Batch Added Successfully";
        header('location: StudentManagement.php');
        exit();
    }
    


}

?>