<?php

include ('../includes/hash.php');


if($_SESSION['LoggedInLevel'] == '1'){

    $AllDepartmentsQuery = mysqli_query($db,"SELECT * FROM departments");
    $allLoginQuery = mysqli_query($db,"SELECT * FROM auth");
}else {

    $AllDepartmentsQuery = mysqli_query($db,"SELECT * FROM departments WHERE id = '$LoggedInDepartment' ");
    $allLoginQuery = mysqli_query($db,"SELECT * FROM auth WHERE dept_assigned = '$LoggedInDepartment' ");

}



if(isset($_POST['AddLogin'])){

    $username = filterData($_POST['username']);
    $email = filterData($_POST['email']);
    $email = strtolower($email);
    $log_type = 2;
    $password = HashFunction(filterData($_POST['password']));
    $department = filterData($_POST['department']);

    $check = mysqli_query($db,"SELECT * FROM auth WHERE email = '$email' LIMIT 1");

    if(mysqli_num_rows($check) > 0){
        $_SESSION['errorsession'] = "Email Already Exists";
        header('location: LoginManagement.php');
        exit();

    }

    $insert = mysqli_query($db,"INSERT INTO auth (username, email, pass, log_type, dept_assigned) VALUES ('$username','$email','$password','$log_type','$department')");

    if($insert) {

        $_SESSION['successsession'] = "Login Has Been Created Successfully!";
        header('location: LoginManagement.php');
        exit();

    }

}

if(isset($_GET['action']))
{
    if($_GET['action'] == 'delete'){
        $user = $_GET['loginId'];

        $query = mysqli_query($db, "DELETE FROM auth WHERE id = '$user'");

        if($query){
            $_SESSION['successsession'] = "Login Deleted Successfully!";
            header('location: LoginManagement.php');
            exit();
        }
    }
}

?>