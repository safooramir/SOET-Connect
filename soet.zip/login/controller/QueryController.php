<?php

if ($_SESSION['LoginType'] == 'MAINADMIN') {

    $AllDepartmentsQuery = mysqli_query($db,"SELECT * FROM departments");


}



?>