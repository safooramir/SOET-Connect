<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php 

if(isset($_POST['addsubject'])){
    $subjectname = $_POST['subjectname'];
    $subjectcode = $_POST['subjectcode'];
    $department = $_POST['department'];
    $teacher = $_POST['teacher'];
    $semester = $_POST['semester'];

    $addSubject = mysqli_query($db,"INSERT INTO subjects
    (department,semester,subject_name,teacher_assigned,subject_code)
    VALUES('$department','$semester','$subjectname','$teacher','$subjectcode')");

    if($addSubject){
        $_SESSION['successsession'] = "New Subject Added Successfully";
        header('location: SubjectManagement.php');
        exit();
    }
}


?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Add New Subject</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <a href="#" class="btn btn-lg btn-warning">View Notice</a>
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card p-5">
          
  
          <!-- Content Goes Here -->
          
                      <!-- Light table -->
            <form name="addsubject" action="AddSubject.php" method="POST">
            
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Subject Name</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="subjectname" class="form-control" placeholder="Enter Subject Name" type="text">
            </div>
            </div>

            <div class="form-group">       
           <div class="text-muted mb-2">Enter Subject Code</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="subjectcode" class="form-control" placeholder="Enter Subject Code" type="text">
            </div>
            </div>

            <div class="form-group">       
           <div class="text-muted mb-2">Enter Department</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                
                <select name="department" id="" class="form-control">
                    <?php

                    $getdepartments = mysqli_query($db,"SELECT * FROM departments");


                    if($_SESSION['LoggedInDepartment'] == 0) {

                      echo '<option value="0">All</option>';
                      
                      while($department = mysqli_fetch_assoc($getdepartments)){

                        echo '<option value="'.$department['id'].'">'.$department['department_name'].'</option>';

                      }
                    }else{
                      echo '<option value="'.$_SESSION['LoggedInDepartment'].'">'.$_SESSION['LoggedInDepartmentName'].'</option>';

                    }

                    ?>
                </select>
        
       </div>
            </div>
            <div class="form-group">       
           <div class="text-muted mb-2">Enter Teacher</div>
            <div class="input-group input-group-merge input-group-alternative mb-2">
                
                <select name="teacher" id="" class="form-control">
                    <?php

                    if($_SESSION['LoggedInDepartment'] == 0) {

                        $getteachers = mysqli_query($db,"SELECT * FROM teachers");

                    }else{

                        $getteachers = mysqli_query($db,"SELECT * FROM teachers WHERE teacher_department = ".$_SESSION['LoggedInDepartment']."");
                    }
                    


                    while($teacher = mysqli_fetch_assoc($getteachers)){

                        echo '<option value="'.$teacher['id'].'">'.$teacher['teacher_name'].'</option>';

                      }
                  
                    ?>
                </select>
      
        </div>
       </div>
            <div class="form-group">       
                <div class="text-muted mb-2">Enter Semester</div>
            <select name="semester" id="" class="form-control">
                    <?php

                    $getsemesters = mysqli_query($db,"SELECT * FROM semesters");


                    while($semester = mysqli_fetch_assoc($getsemesters)){

                        echo '<option value="'.$semester['id'].'">'.$semester['semester'].'</option>';

                      }
                  
                    ?>
                </select>
            </div>
           

         
            
            <button name="addsubject" class="btn btn-success btn-lg">Add Subject</button>

            
            </form>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>