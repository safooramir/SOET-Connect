<?php include ('../api/db.php'); ?>
<?php include ('../includes/filter.php'); ?>
<?php include ('controller/authController.php'); ?>
<?php include ('controller/LoginController.php'); ?>
<?php include ('../login/includes/header.php') ?>
    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h6 class="h2 text-white d-inline-block mb-0">Add/Manage Login</h6>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Dashboards</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Default</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
            <!-- Menu Buttons Here -->
              <!-- Button trigger modal -->
<button type="button"class="btn btn-lg btn-warning" data-toggle="modal" data-target="#exampleModal">
  Add New Login
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" class="text-align-left">
      
      <form action="LoginManagement.php" method="POST" name="AddLogin">      
            <div class="form-group">    
            <p class="text-justify">Username</p>   
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="username" class="form-control" placeholder="Username"  type="text" required="">
            </div>
            </div>
            <div class="form-group">     
            <p class="text-justify">Email</p>   
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="email" class="form-control" placeholder="Email"  type="email" required="">
            </div>
            </div>
            <div class="form-group">     
            <p class="text-justify">Password</p>     
            <div class="input-group input-group-merge input-group-alternative mb-2">
                <input name="password" class="form-control" placeholder="Password"  type="text" required="">
            </div>
            </div>
            <div class="form-group">       
          <p class="text-justify">Department</p>
                <select class="form-control" name="department" id="">
                <?php 
                    while($dept = mysqli_fetch_assoc($AllDepartmentsQuery)){
                        echo '<option value="'.$dept['id'].'">'.$dept['department_name'].'</option>';

                    }
                ?>
                </select>                
            
            </div>


            <button name="AddLogin" class="btn btn-primary">Add Login</button>


        
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
              
            </div>
          </div>
          <!-- Card stats -->
         
        </div>
      </div>
    </div>
    <!-- Page content -->
    <div class="container-fluid mt--6">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
          <?php include('../includes/dialog.php'); ?>
          
          <!-- Content Goes Here -->
                      <!-- Light table -->
            <div class="table-responsive p-4">
              <table id="table_id" class="table align-items-center table-flush p-2">
                <thead class="thead-light">
                  <tr>
                    <th scope="col" class="sort" data-sort="name">Username</th>
                    <th scope="col" class="sort" data-sort="budget">Email</th>
                    <th scope="col" class="sort" data-sort="status">Department</th>
                    <th scope="col">Actions</th>
                  </tr>
                </thead>
                <tbody class="list">
                    
                    <?php

                      while($login = mysqli_fetch_assoc($allLoginQuery)){
                        $deptas = $login['dept_assigned'];
                        $getdepartment = mysqli_query($db,"SELECT department_name FROM departments WHERE id = '$deptas'");
                        $depart = mysqli_fetch_assoc($getdepartment);


                        if($login['log_type'] == '1'){

                          $DepartmentName = 'SoET';

                        }else{
                          $DepartmentName = $depart['department_name'];

                        }

                        echo '<tr>
                        <th scope="row">
                          <div class="media align-items-center">
                           
                            <div class="media-body">
                              <span class="name mb-0 text-sm">'.$login['username'].'</span>
                            </div>
                          </div>
                        </th>
                        <td class="budget">
                        '.$login['email'].'
                        </td>
                        <td>
                          <span class="badge badge-dot mr-4">
                           
                            <span class="status">'.$DepartmentName.'</span>
                          </span>
                        </td>
                      
                        
                        <td class="text-right">
                          <div class="dropdown">
                            <a class="btn btn-sm btn-info" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             Manage
                            </a>
                            <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                              <a class="dropdown-item" href="LoginManagement.php?action=delete&loginId='.$login['id'].'">Delete</a>
                            </div>
                          </div>
                        </td>
                      </tr>';

                      }

                    ?>

     
               
              
                 
                </tbody>
              </table>
            </div>
          </div>
        </div>
 
      </div>
   
      <!-- Footer -->

    </div>
  </div>
  <?php include ('../login/includes/footer.php');?>