<?php

if(!isset($_SESSION['department_session'])){

    header('location: index.php');
    exit();
}

if(!isset($_SESSION['semester_session'])){
    header('location: index.php');
    exit();
}

?>