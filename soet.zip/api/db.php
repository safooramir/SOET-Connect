<?php

session_start();


function Connection () {
    $db = mysqli_connect('localhost', 'root','','soetconnect');

    return $db;
}

$db = Connection();

?>