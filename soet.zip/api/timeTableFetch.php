<?php

include "../api/db.php";
include "../Controller/MainLogic.php";

$Query = mysqli_query($db,"SELECT * FROM timetablelinks WHERE department = '$DEPARTMENT' AND semester ='$SEMESTER'");

$TT = mysqli_fetch_assoc($Query);

$GoogleSheetsJson = file_get_contents($TT['link']);

$GoogleSheetsJson = json_decode($GoogleSheetsJson);

$rows = $GoogleSheetsJson->{'feed'}->{'entry'};

$NewArray = array();

foreach($rows as $row) {

    $fetch_details = mysqli_query($db,"SELECT * FROM subjects WHERE subject_code = '".$row->{'gsx$subjectcode'}->{'$t'}."'");

    $fetch_array = mysqli_fetch_assoc($fetch_details);

    $teacher_flag = 1;
    $teacher_assigned = '';

    if(mysqli_num_rows($fetch_details) > 0){
        $subject_name =  $fetch_array['subject_name'];
      
    }else{
        $subject_name = "Not Available";
        $teacher_flag = 0;
    }
    

    if($teacher_flag == 0){

        $teacher_assigned = 'Not Available';

        $teacher_link = '#';

        $image_link = 'default-user.png';
    }else{

        $fetch_teacher_name = mysqli_query($db,"SELECT * FROM teachers WHERE id = '".$fetch_array['teacher_assigned']."' ");

        $teacher = mysqli_fetch_array($fetch_teacher_name);
        
        $teacher_assigned =  $teacher['teacher_name'];

        $teacher_link =  $teacher['id'];

        $image_link = $teacher['image'];
    }
    
    $timeTableObj = ((object)[
        "date"=> $row->{'gsx$date'}->{'$t'},
        "starttime"=> $row->{'gsx$starttime'}->{'$t'},
        "endtime"=> $row->{'gsx$endtime'}->{'$t'},
        "subject_code"=> $row->{'gsx$subjectcode'}->{'$t'},
        "teacher_name" => $teacher_assigned,
        "subject_name"=> $subject_name,
        "teacher_link" => $teacher_link,
        "image_link" => $image_link
        

    ]);

    array_push($NewArray, $timeTableObj);

}

echo $json = json_encode($NewArray);


?>